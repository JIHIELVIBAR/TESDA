<?php
$conn = mysqli_connect("localhost", "root", "", "eazy_shop");
if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }

// --- ORDER PROCESSING LOGIC (UNTOUCHED) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['place_order'])) {
    $p_name = mysqli_real_escape_string($conn, $_POST['p_name']);
    $qty = (int)$_POST['qty'];
    $price = (float)$_POST['p_price'];
    $total = $qty * $price;
    $c_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $c_phone = mysqli_real_escape_string($conn, $_POST['contact']);
    $c_address = mysqli_real_escape_string($conn, $_POST['address']);

    $sql = "INSERT INTO orders (product_name, quantity, total_price, customer_name, contact_number, address) 
            VALUES ('$p_name', '$qty', '$total', '$c_name', '$c_phone', '$c_address')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Order Placed Successfully!'); window.location.href='index.php';</script>";
    }
}

$result = mysqli_query($conn, "SELECT * FROM product");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eazy Shop | Pink Edition</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-pink: #ff85a2;
            --soft-pink: #fce4ec;
            --dark-pink: #f06292;
            --accent-gold: #d4af37;
            --bg-light: #fff5f7;
        }

        body { 
            background-color: var(--bg-light); 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: #444;
        }

        /* --- NAVIGATION --- */
        nav { 
            background: white; 
            padding: 20px; 
            box-shadow: 0 4px 15px rgba(255, 133, 162, 0.1); 
            margin-bottom: 40px; 
            text-align: left;
        }
        nav h5 { 
            margin: 0; 
            font-weight: 600; 
            color: var(--primary-pink); 
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        /* --- GRID LAYOUT --- */
        .row-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); 
            gap: 30px; 
            padding: 20px; 
            max-width: 1200px; 
            margin: 0 auto; 
        }

        /* --- PRODUCT CARDS --- */
        .product-card { 
            background: white; 
            border-radius: 20px; 
            border: none; 
            overflow: hidden; 
            display: flex; 
            flex-direction: column; 
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.02);
        }

        .product-card:hover { 
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15); 
        }

        .product-card img { 
            width: 100%; 
            height: 220px; 
            object-fit: contain; 
            padding: 20px;
            background: #fff;
        }

        .product-info { 
            padding: 20px; 
            text-align: center; 
            background: white;
        }

        .product-name { 
            font-size: 15px; 
            font-weight: 600; 
            margin-bottom: 8px; 
            height: 45px; 
            overflow: hidden; 
            color: #333;
        }

        .product-price { 
            color: var(--primary-pink); 
            font-size: 20px; 
            font-weight: 600; 
            margin-bottom: 15px; 
        }

        /* --- BUTTON ANIMATIONS (MINIMAL) --- */
        .btn-buy { 
            background-color: var(--primary-pink); 
            color: white; 
            width: 100%; 
            border: none; 
            padding: 12px; 
            border-radius: 12px; 
            font-weight: 600;
            transition: background 0.2s ease;
        }

        .btn-buy:hover { 
            background-color: var(--dark-pink); 
            color: white;
        }

        .btn-buy:active {
            transform: scale(0.98); /* Minimal "click" effect */
        }

        /* --- MODAL STYLING --- */
        .modal-content {
            border-radius: 25px;
            border: none;
            overflow: hidden;
        }

        .modal-header {
            background-color: var(--soft-pink);
            border-bottom: none;
            padding: 20px 30px;
        }

        .modal-title { color: var(--dark-pink); font-weight: 600; }

        #modal-img { 
            width: 140px; 
            height: 140px; 
            object-fit: contain; 
            margin-bottom: 15px; 
            border-radius: 15px; 
            background: white;
            padding: 10px;
            box-shadow: 0 5px 10px rgba(0,0,0,0.05);
        }

        .form-control {
            border-radius: 10px;
            border: 1px solid #eee;
            padding: 10px 15px;
        }

        .form-control:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 0.25rem rgba(255, 133, 162, 0.25);
        }

        .btn-success {
            background-color: var(--primary-pink);
            border: none;
            border-radius: 10px;
            padding: 10px 25px;
        }

        .btn-success:hover {
            background-color: var(--dark-pink);
        }
    </style>
</head>
<body>

<nav><h5>Snack Shop</h5></nav>

<div class="row-grid">
    <?php while($product = mysqli_fetch_assoc($result)): ?>
        <div class="product-card">
            <img src="<?php echo $product['image_url']; ?>" alt="Product">
            <div class="product-info">
                <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
                
                <button class="btn btn-buy" 
                        data-bs-toggle="modal" 
                        data-bs-target="#buyModal" 
                        data-name="<?php echo htmlspecialchars($product['name']); ?>" 
                        data-price="<?php echo $product['price']; ?>"
                        data-img="<?php echo $product['image_url']; ?>">
                    Buy Now
                </button>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<div class="modal fade" id="buyModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="POST">
          <div class="modal-header">
            <h5 class="modal-title">Complete Your Order</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body text-center px-4">
            
            <img id="modal-img" src="" alt="Product Image">
            
            <h5 id="modal-p-name" class="fw-bold mb-1"></h5>
            <p class="text-muted small">Unit Price: ₱<span id="modal-p-price"></span></p>
            <hr class="opacity-25">

            <input type="hidden" name="p_name" id="hidden-name">
            <input type="hidden" name="p_price" id="hidden-price">

            <div class="text-start">
                <div class="row mb-3 align-items-center">
                    <div class="col-6">
                        <label class="form-label fw-bold small text-uppercase">Quantity</label>
                        <input type="number" name="qty" id="qty" class="form-control" value="1" min="1" required oninput="calculateTotal()">
                    </div>
                    <div class="col-6 text-end">
                        <label class="form-label fw-bold small text-uppercase text-pink" style="color: var(--primary-pink);">Total</label>
                        <h3 class="fw-bold" style="color: var(--dark-pink);">₱<span id="modal-total">0.00</span></h3>
                    </div>
                </div>

                <div class="mb-2">
                    <label class="form-label small text-uppercase fw-semibold">Full Name</label>
                    <input type="text" name="full_name" class="form-control" placeholder="Recipient Name" required>
                </div>
                <div class="mb-2">
                    <label class="form-label small text-uppercase fw-semibold">Contact Number</label>
                    <input type="text" name="contact" class="form-control" placeholder="( +63 900 000 0000 )" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small text-uppercase fw-semibold">Shipping Address</label>
                    <textarea name="address" class="form-control" rows="2" placeholder="Street, Barangay, City, Country" required></textarea>
                </div>
            </div>
          </div>
          <div class="modal-footer border-0 pb-4 justify-content-center">
            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Back</button>
            <button type="submit" name="place_order" class="btn btn-success px-5 shadow-sm">Confirm Order</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    let currentPrice = 0;
    const buyModal = document.getElementById('buyModal');

    buyModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const name = button.getAttribute('data-name');
        const img = button.getAttribute('data-img');
        currentPrice = parseFloat(button.getAttribute('data-price'));

        document.getElementById('modal-img').src = img;
        document.getElementById('modal-p-name').textContent = name;
        document.getElementById('modal-p-price').textContent = currentPrice.toFixed(2);
        
        document.getElementById('hidden-name').value = name;
        document.getElementById('hidden-price').value = currentPrice;

        document.getElementById('qty').value = 1;
        calculateTotal();
    });

    function calculateTotal() {
        const qty = document.getElementById('qty').value;
        const total = currentPrice * qty;
        document.getElementById('modal-total').textContent = total.toLocaleString(undefined, {minimumFractionDigits: 2});
    }
</script>

</body>
</html>