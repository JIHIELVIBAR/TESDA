<?php
$conn = new mysqli("localhost", "root", "", "school_quiz_db");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$questions = [];
// Initial fetch from DB
$sql = "SELECT * FROM quiz_questions ORDER BY RAND()";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quiz Application</title>

<style>
:root {
    --primary-pink: #d48498;
    --secondary-pink: #f9ecee;
    --accent-pink: #9e5a6a;
    --text-main: #4a4a4a;
    --white: #ffffff;
}

body {
    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    background-color: var(--secondary-pink);
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    color: var(--text-main);
}

/* Updated Header Styling */
.quiz-header {
    width: 100%;
    background-color: var(--primary-pink);
    color: white;
    text-align: center;
    padding: 20px 0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 40px;
}

#score-display-container {
    font-size: 1.5rem;
    font-weight: 300;
    letter-spacing: 1px;
}

/* Quiz Card */
.quiz-card {
    background: var(--white);
    padding: 30px;
    border-radius: 4px;
    box-shadow: 0 10px 30px rgba(158, 90, 106, 0.15);
    width: 90%;
    max-width: 450px;
    text-align: center;
    border-top: 5px solid var(--accent-pink);
}

.image-container img {
    width: 100%;
    height: 280px;
    object-fit: cover;
    border-radius: 2px;
    margin-bottom: 25px;
    border: 1px solid #eee;
}

.options-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.option-btn {
    padding: 14px;
    border: 1px solid var(--primary-pink);
    background: var(--white);
    color: var(--accent-pink);
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.95rem;
    font-weight: 500;
    transition: all 0.2s ease;
}

.option-btn:hover:not(:disabled) {
    background-color: var(--primary-pink);
    color: white;
}

.correct {
    background: #2ecc71 !important;
    color: white !important;
    border-color: #2ecc71 !important;
}

.wrong {
    background: #e74c3c !important;
    color: white !important;
    border-color: #e74c3c !important;
}

.finished-msg h2 { color: var(--accent-pink); }
</style>

</head>
<body>

<header class="quiz-header">
    <div id="score-display-container">
        Score: <span id="score-count">0</span>
    </div>
</header>

<div class="quiz-card" id="quiz-container">
    <div class="image-container">
        <img id="quiz-image" src="" alt="Question Image">
    </div>

    <div class="options-grid">
        <button class="option-btn" onclick="checkAnswer(this)" id="btn1"></button>
        <button class="option-btn" onclick="checkAnswer(this)" id="btn2"></button>
        <button class="option-btn" onclick="checkAnswer(this)" id="btn3"></button>
        <button class="option-btn" onclick="checkAnswer(this)" id="btn4"></button>
    </div>
</div>

<script>
// Load initial questions from PHP
let masterQuestions = <?php echo json_encode($questions); ?>;
let questions = [];
let currentQuestion = {};
let score = 0;

// Helper function to shuffle array (Fisher-Yates)
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function initQuiz() {
    score = 0;
    document.getElementById("score-count").innerText = score;
    // Clone and Shuffle the master list so every restart is different
    questions = shuffle([...masterQuestions]); 
    loadQuestion();
}

function loadQuestion() {
    if (questions.length === 0) {
        document.getElementById("quiz-container").innerHTML = `
            <div class="finished-msg">
                <h2>Quiz Completed</h2>
                <p>Total Score: ${score}</p>
                <button class="option-btn" onclick="location.reload()" style="width:100%">Restart Quiz</button>
            </div>`;
        return;
    }

    currentQuestion = questions.shift();
    document.getElementById("quiz-image").src = currentQuestion.image;
    
    // Set button texts
    const buttons = [
        document.getElementById("btn1"),
        document.getElementById("btn2"),
        document.getElementById("btn3"),
        document.getElementById("btn4")
    ];

    buttons.forEach((btn, index) => {
        btn.innerText = currentQuestion['option' + (index + 1)];
        btn.classList.remove("correct", "wrong");
        btn.disabled = false;
    });
}

function checkAnswer(button) {
    // Disable all buttons to prevent double clicking during the timeout
    const buttons = document.querySelectorAll(".option-btn");
    buttons.forEach(btn => btn.disabled = true);

    let selected = button.innerText;

    if (selected === currentQuestion.correct_answer) {
        score++;
        document.getElementById("score-count").innerText = score;
        button.classList.add("correct");
    } else {
        button.classList.add("wrong");
        // Optional: Highlight the correct one so the user learns
        buttons.forEach(btn => {
            if(btn.innerText === currentQuestion.correct_answer) {
                btn.classList.add("correct");
            }
        });
    }

    // Continue to next question regardless of answer
    setTimeout(loadQuestion, 1200);
}

// Start the quiz for the first time
initQuiz();
</script>

</body>
</html>