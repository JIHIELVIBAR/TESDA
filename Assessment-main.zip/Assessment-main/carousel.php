<?php
$conn = new mysqli(hostname: "localhost", username: "root", password: "", database: "countries_db");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

if ($search != "") {
    $stmt = $conn->prepare(query: "SELECT * FROM countries WHERE name LIKE ?");
    $like = "%" . $search . "%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query(query: "SELECT * FROM countries");
}

$countries = [];
while ($row = $result->fetch_assoc()) {
    $countries[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Country Carousel</title>
  <style>
    body {
      margin: 0;
      font-family: HELVETICA;
      background: #eef2ff;
      /* Very light blue background */
    }

    /* Top Bar - Deep Blue */
    .top-bar {
      width: 100%;
      background: #1e3a8a;
      /* Deep Royal Blue */
      padding: 35px 0;
      text-align: center;
      box-shadow: 0 4px 12px rgba(30, 58, 138, 0.2);
    }

    .top-bar form {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .top-bar input {
      padding: 14px 25px;
      width: 320px;
      max-width: 60%;
      font-size: 16px;
      border-radius: 30px 0 0 30px;
      border: 2px solid #3b82f6;
      /* Blue border */
      border-right: none;
      outline: none;
      background: #ffffff;
    }

    .top-bar button {
      padding: 14px 25px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      background: #3b82f6;
      /* Bright Blue */
      color: white;
      border: 2px solid #3b82f6;
      border-radius: 0 30px 30px 0;
      transition: background 0.2s;
    }

    .top-bar button:hover {
      background: #2563eb;
      /* Slightly darker blue on hover */
      border-color: #2563eb;
    }

    /* Container */
    .container {
      width: 850px;
      max-width: 95%;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 24px;
      border: 1px solid #dbeafe;
      /* Soft blue border */
      box-shadow: 0 10px 30px rgba(30, 58, 138, 0.1);
      position: relative;
    }

    .carousel {
      overflow: hidden;
      width: 100%;
      position: relative;
      border-radius: 16px;
    }

    .slides {
      display: flex;
      transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .slide {
      min-width: 100%;
      text-align: center;
    }

    .slide img {
      width: 100%;
      max-width: 450px;
      height: auto;
      border-radius: 12px;
      border: 3px solid #eff6ff;
      /* Light blue image frame */
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }

    /* Country Info - Blue Text */
    .country-info {
      margin-top: 20px;
      font-size: 20px;
      padding: 15px;
      text-align: center;
    }

    .country-info strong {
      font-size: 32px;
      color: #1e40af;
      /* Bold Blue */
      display: block;
      margin-bottom: 8px;
    }

    .country-info span {
      display: block;
      font-size: 18px;
      color: #60a5fa;
      /* Sky Blue Subtext */
      font-weight: 600;
    }

    /* Nav Buttons - Blue Theme */
    .nav-btn {
      position: absolute;
      top: 40%;
      transform: translateY(-50%);
      font-size: 28px;
      background: rgba(239, 246, 255, 0.9);
      /* Translucent light blue */
      color: #1e40af;
      width: 50px;
      height: 50px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      user-select: none;
      border-radius: 50%;
      box-shadow: 0 4px 10px rgba(30, 58, 138, 0.2);
      transition: all 0.2s ease;
    }

    .nav-btn:hover {
      background: #1e40af;
      color: white;
    }

    .prev {
      left: 15px;
    }

    .next {
      right: 15px;
    }

    h2 {
      color: #3b82f6;
    }
  </style>
</head>

<body>
  <div class="top-bar">
    <form method="GET">
      <input type="text" name="search" placeholder="Search country..." value="<?= htmlspecialchars(string: $search)?>">
      <button type="submit">Search</button>
    </form>
  </div>

  <div class="container">

    <?php if (count($countries) > 0): ?>

    <div class="carousel">
    <div class="slides" id="slides">

        <?php foreach ($countries as $country): ?>

            <div class="slide">
                <img src="<?= htmlspecialchars($country['image']) ?>">
                <div class="country-info">
                    <strong><?= $country['name'] ?></strong>
                    <span>Capital: <?= $country['capital'] ?></span>
                </div>
            </div>

        <?php endforeach; ?>

    </div>
</div>

    <div class="nav-btn prev" onclick="moveSlide(-1)">&#10094;</div>
    <div class="nav-btn next" onclick="moveSlide(1)">&#10095;</div>

    <?php else: ?>

    <h2 style="text-align:center;">No Country Found</h2>

    <?php endif; ?>

  </div>

  <script>
    let index = 0;

    function moveSlide(step) {
      const slides = document.getElementById('slides');
      const totalSlides = document.querySelectorAll('.slide').length;

      index += step;

      if (index < 0) index = totalSlides - 1;
      if (index >= totalSlides) index = 0;

      slides.style.transform = 'translateX(' + (-index * 100) + '%)';
    }
  </script>
</body>

</html>