<?php
// ============================================
// TESDA Web Development NC III - Quiz Game
// Single File: PHP + HTML + CSS + JavaScript
// Fruits & Vegetables Multiple Choice Quiz
// ============================================

// Database Configuration
header('Content-Type: text/html; charset=utf-8');

// Handle API Requests
$action = $_GET['action'] ?? '';
if ($action) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    
    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'quiz_game');
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
    $conn->set_charset("utf8mb4");
    
    switch ($action) {
        case 'get_questions':
            $sql = "SELECT id, image_url, correct_answer, option_a, option_b, option_c, option_d, category 
                    FROM questions ORDER BY RAND() LIMIT 10";
            $result = $conn->query($sql);
            $questions = [];
            while ($row = $result->fetch_assoc()) {
                $options = [$row['option_a'], $row['option_b'], $row['option_c'], $row['option_d']];
                shuffle($options);
                $questions[] = [
                    'id' => $row['id'],
                    'image_url' => $row['image_url'],
                    'correct_answer' => $row['correct_answer'],
                    'options' => $options,
                    'category' => $row['category']
                ];
            }
            echo json_encode(['questions' => $questions]);
            break;
            
        case 'save_score':
            $data = json_decode(file_get_contents('php://input'), true);
            $username = $conn->real_escape_string($data['username'] ?? '');
            $score = intval($data['score'] ?? 0);
            $total = intval($data['total_questions'] ?? 10);
            $started = $conn->real_escape_string($data['date_started'] ?? '');
            $ended = $conn->real_escape_string($data['date_ended'] ?? '');
            $duration = intval($data['duration_seconds'] ?? 0);
            
            $sql = "INSERT INTO scores (username, score, total_questions, date_started, date_ended, duration_seconds) 
                    VALUES ('$username', $score, $total, '$started', '$ended', $duration)";
            
            if ($conn->query($sql)) {
                echo json_encode(['success' => true, 'message' => 'Score saved']);
            } else {
                echo json_encode(['error' => 'Failed to save']);
            }
            break;
            
        case 'get_highscores':
            $sql = "SELECT username, score, total_questions, date_started, duration_seconds 
                    FROM scores ORDER BY score DESC, duration_seconds ASC LIMIT 10";
            $result = $conn->query($sql);
            $scores = [];
            while ($row = $result->fetch_assoc()) {
                $scores[] = [
                    'username' => $row['username'],
                    'score' => $row['score'],
                    'total_questions' => $row['total_questions'],
                    'date_played' => date('m/d/Y', strtotime($row['date_started'])),
                    'time' => $row['duration_seconds'] < 60 ? $row['duration_seconds'] . ' seconds' : 
                              floor($row['duration_seconds']/60) . ' min ' . ($row['duration_seconds']%60) . ' sec'
                ];
            }
            echo json_encode(['highscores' => $scores]);
            break;
    }
    $conn->close();
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TESDA Quiz Game - Fruits & Vegetables</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #4f46e5; --primary-hover: #4338ca;
            --success: #10b981; --danger: #ef4444;
            --bg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --card: #fff; --text: #1f2937; --gray: #6b7280;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg); min-height: 100vh;
            display: flex; flex-direction: column;
        }
        .container { flex: 1; max-width: 800px; width: 100%; margin: 0 auto; padding: 20px; }
        header { text-align: center; padding: 30px 20px; color: white; }
        header h1 { font-size: 2.5rem; font-weight: 700; text-shadow: 2px 2px 4px rgba(0,0,0,0.2); }
        header p { font-size: 1.2rem; opacity: 0.9; }
        .screen { display: none; animation: fadeIn 0.3s ease; }
        .screen.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; } }
        .card {
            background: var(--card); border-radius: 16px; padding: 30px;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); margin-bottom: 20px;
        }
        .card h2 { font-size: 1.8rem; margin-bottom: 15px; text-align: center; }
        .desc { text-align: center; color: var(--gray); margin-bottom: 25px; line-height: 1.6; }
        .input-group { margin-bottom: 25px; }
        .input-group label { display: block; margin-bottom: 8px; font-weight: 500; }
        .input-group input {
            width: 100%; padding: 14px 18px; border: 2px solid #e5e7eb;
            border-radius: 10px; font-size: 1rem; font-family: inherit;
        }
        .input-group input:focus { outline: none; border-color: var(--primary); }
        .error { color: var(--danger); font-size: 0.85rem; margin-top: 5px; min-height: 20px; }
        .btn {
            display: inline-block; padding: 14px 32px; border: none;
            border-radius: 10px; font-size: 1rem; font-weight: 600;
            cursor: pointer; transition: all 0.3s; text-align: center;
            width: 100%; margin-bottom: 10px; font-family: inherit;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-hover); transform: translateY(-2px); }
        .btn-secondary { background: transparent; color: var(--primary); border: 2px solid var(--primary); }
        .btn-secondary:hover { background: var(--primary); color: white; }
        .rules { margin-top: 30px; padding: 20px; background: #f9fafb; border-radius: 10px; }
        .rules h3 { font-size: 1.1rem; margin-bottom: 12px; }
        .rules ul { list-style: none; }
        .rules li { padding: 8px 0; padding-left: 25px; position: relative; color: var(--gray); }
        .rules li::before { content: "✓"; position: absolute; left: 0; color: var(--success); font-weight: bold; }
        .game-header {
            display: flex; justify-content: space-between; align-items: center;
            background: rgba(255,255,255,0.95); padding: 15px 25px;
            border-radius: 12px; margin-bottom: 20px;
        }
        .game-stats { display: flex; gap: 20px; }
        .stat strong { color: var(--primary); font-size: 1.2rem; }
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin-bottom: 25px; }
        .progress-fill {
            height: 100%; background: linear-gradient(90deg, var(--primary), var(--success));
            border-radius: 4px; transition: width 0.3s; width: 10%;
        }
        .image-wrapper {
            position: relative; width: 100%; max-width: 350px; margin: 0 auto 25px;
            aspect-ratio: 1; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            background: #f9fafb;
        }
        .image-wrapper img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .loading { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); color: var(--gray); }
        .question-text { font-size: 1.4rem; margin-bottom: 25px; text-align: center; }
        .options-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
        .option-btn {
            padding: 18px 20px; border: 2px solid #e5e7eb; border-radius: 12px;
            background: white; font-size: 1.1rem; font-weight: 500; cursor: pointer;
            transition: all 0.2s; font-family: inherit;
        }
        .option-btn:hover:not(:disabled) { border-color: var(--primary); background: #f5f3ff; transform: translateY(-2px); }
        .option-btn.correct { background: #d1fae5; border-color: var(--success); color: #065f46; }
        .option-btn.wrong { background: #fee2e2; border-color: var(--danger); color: #991b1b; }
        .option-btn:disabled { cursor: not-allowed; opacity: 0.7; }
        .feedback {
            margin-top: 20px; padding: 15px; border-radius: 10px; text-align: center;
            font-weight: 600; font-size: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 10px;
        }
        .feedback.correct { background: #d1fae5; color: #065f46; }
        .feedback.wrong { background: #fee2e2; color: #991b1b; }
        .hidden { display: none !important; }
        .score-circle {
            width: 150px; height: 150px; border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--success));
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            margin: 0 auto 20px; color: white;
        }
        .score-circle span { font-size: 3rem; font-weight: 700; }
        .results-details { background: #f9fafb; border-radius: 12px; padding: 20px; margin: 25px 0; }
        .detail-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #e5e7eb; }
        .detail-row:last-child { border-bottom: none; }
        .detail-row span { color: var(--gray); }
        .save-status { margin: 15px 0; padding: 12px; border-radius: 8px; font-weight: 500; text-align: center; }
        .save-status.success { background: #d1fae5; color: #065f46; }
        .save-status.error { background: #fee2e2; color: #991b1b; }
        .button-group { display: flex; gap: 10px; margin-top: 25px; }
        .button-group .btn { flex: 1; margin-bottom: 0; }
        .table-container { overflow-x: auto; margin: 25px 0; }
        table { width: 100%; border-collapse: collapse; font-size: 0.95rem; }
        th, td { padding: 14px 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; }
        tr:hover { background: #f9fafb; }
        td:nth-child(3) { font-weight: 600; color: var(--primary); }
        .rank-1 { color: #f59e0b; font-weight: 700; }
        .rank-2 { color: #9ca3af; font-weight: 700; }
        .rank-3 { color: #b45309; font-weight: 700; }
        .no-scores { text-align: center; padding: 40px; color: var(--gray); }
        footer { text-align: center; padding: 20px; color: rgba(255,255,255,0.8); font-size: 0.9rem; }
        @media (max-width: 600px) {
            header h1 { font-size: 1.8rem; }
            .card { padding: 20px; }
            .options-grid { grid-template-columns: 1fr; }
            .game-header { flex-direction: column; gap: 10px; text-align: center; }
            .button-group { flex-direction: column; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🎯 Multiple Choice Quiz Game</h1>
            <p>Fruits & Vegetables Edition</p>
        </header>

        <!-- Welcome Screen -->
        <div id="welcome-screen" class="screen active">
            <div class="card">
                <h2>Welcome to the Quiz!</h2>
                <p class="desc">Test your knowledge of fruits and vegetables!<br>You will be shown 10 random images. Identify each one correctly.</p>
                <div class="input-group">
                    <label>Enter Your Name:</label>
                    <input type="text" id="player-name" placeholder="Your name here..." maxlength="50">
                    <span id="name-error" class="error"></span>
                </div>
                <button id="start-btn" class="btn btn-primary">Start Game</button>
                <div class="rules">
                    <h3>📋 Game Rules:</h3>
                    <ul>
                        <li>10 random questions per game</li>
                        <li>1 point for each correct answer</li>
                        <li>No time limit - play at your own pace</li>
                        <li>Your score will be saved to the leaderboard</li>
                    </ul>
                </div>
            </div>
            <button id="view-highscores-btn" class="btn btn-secondary">View High Scores</button>
        </div>

        <!-- Game Screen -->
        <div id="game-screen" class="screen">
            <div class="game-header">
                <div>Player: <strong id="current-player">-</strong></div>
                <div class="game-stats">
                    <span class="stat">Question: <strong id="question-number">1</strong>/10</span>
                    <span class="stat">Score: <strong id="current-score">0</strong></span>
                </div>
            </div>
            <div class="card">
                <div class="progress-bar"><div id="progress-fill" class="progress-fill"></div></div>
                <div class="image-wrapper">
                    <img id="question-image" src="" alt="Question">
                    <div id="loading" class="loading">Loading...</div>
                </div>
                <h3 class="question-text">What is this?</h3>
                <div id="options-container" class="options-grid"></div>
                <div id="feedback" class="feedback hidden"></div>
            </div>
        </div>

        <!-- Results Screen -->
        <div id="results-screen" class="screen">
            <div class="card" style="text-align:center;">
                <h2>🎉 Game Complete!</h2>
                <div style="margin:30px 0;">
                    <div class="score-circle">
                        <span id="final-score">0</span>
                        <small>/ 10</small>
                    </div>
                    <p id="score-message"></p>
                </div>
                <div class="results-details">
                    <div class="detail-row"><span>Player:</span><strong id="result-player">-</strong></div>
                    <div class="detail-row"><span>Correct Answers:</span><strong id="result-correct">0/10</strong></div>
                    <div class="detail-row"><span>Duration:</span><strong id="result-duration">-</strong></div>
                    <div class="detail-row"><span>Date Played:</span><strong id="result-date">-</strong></div>
                </div>
                <div id="save-status" class="save-status"></div>
                <div class="button-group">
                    <button id="play-again-btn" class="btn btn-primary">Play Again</button>
                    <button id="view-scores-btn" class="btn btn-secondary">View High Scores</button>
                </div>
            </div>
        </div>

        <!-- High Scores Screen -->
        <div id="highscores-screen" class="screen">
            <div class="card">
                <h2>🏆 High Scores</h2>
                <p class="desc">Top 10 Players</p>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr><th>Rank</th><th>Username</th><th>Score</th><th>Date</th><th>Time</th></tr>
                        </thead>
                        <tbody id="highscores-body"></tbody>
                    </table>
                    <div id="no-scores" class="no-scores hidden">No scores yet. Be the first!</div>
                </div>
                <button id="back-btn" class="btn btn-secondary">Back to Home</button>
            </div>
        </div>
    </div>

    <footer>
        <p>TESDA Web Development NC III - Competency Assessment</p>
    </footer>

    <script>
        // Game State
        let gameState = {
            playerName: '', questions: [], currentQ: 0, score: 0,
            startTime: null, endTime: null, answered: false
        };

        const screens = {
            welcome: document.getElementById('welcome-screen'),
            game: document.getElementById('game-screen'),
            results: document.getElementById('results-screen'),
            highscores: document.getElementById('highscores-screen')
        };

        // Event Listeners
        document.getElementById('start-btn').addEventListener('click', startGame);
        document.getElementById('player-name').addEventListener('keypress', e => { if(e.key==='Enter') startGame(); });
        document.getElementById('view-highscores-btn').addEventListener('click', showHighScores);
        document.getElementById('play-again-btn').addEventListener('click', resetGame);
        document.getElementById('view-scores-btn').addEventListener('click', showHighScores);
        document.getElementById('back-btn').addEventListener('click', () => showScreen('welcome'));

        function showScreen(name) {
            Object.values(screens).forEach(s => s.classList.remove('active'));
            screens[name].classList.add('active');
        }

        async function startGame() {
            const input = document.getElementById('player-name');
            const error = document.getElementById('name-error');
            const name = input.value.trim();

            if (!name) { error.textContent = 'Please enter your name.'; return; }
            if (name.length < 2) { error.textContent = 'Name must be at least 2 characters.'; return; }
            error.textContent = '';
            gameState.playerName = name;

            document.getElementById('start-btn').textContent = 'Loading...';
            document.getElementById('start-btn').disabled = true;

            try {
                const res = await fetch('index.php?action=get_questions');
                const data = await res.json();
                if (data.error) throw new Error(data.error);
                
                gameState.questions = data.questions;
                gameState.currentQ = 0; gameState.score = 0;
                gameState.startTime = new Date(); gameState.answered = false;

                document.getElementById('current-player').textContent = name;
                updateScore();
                showScreen('game');
                loadQuestion();
            } catch(e) {
                alert('Error: ' + e.message);
            } finally {
                document.getElementById('start-btn').textContent = 'Start Game';
                document.getElementById('start-btn').disabled = false;
            }
        }

        function loadQuestion() {
            const q = gameState.questions[gameState.currentQ];
            const progress = ((gameState.currentQ + 1) / 10) * 100;
            document.getElementById('progress-fill').style.width = progress + '%';
            document.getElementById('question-number').textContent = gameState.currentQ + 1;
            document.getElementById('loading').classList.remove('hidden');

            const img = document.getElementById('question-image');
            img.onload = () => document.getElementById('loading').classList.add('hidden');
            img.src = q.image_url;

            const container = document.getElementById('options-container');
            container.innerHTML = '';
            q.options.forEach(opt => {
                const btn = document.createElement('button');
                btn.className = 'option-btn';
                btn.textContent = opt;
                btn.onclick = () => answer(opt, btn);
                container.appendChild(btn);
            });
            document.getElementById('feedback').classList.add('hidden');
            gameState.answered = false;
        }

        function answer(selected, btn) {
            if (gameState.answered) return;
            gameState.answered = true;
            const q = gameState.questions[gameState.currentQ];
            const correct = selected === q.correct_answer;
            if (correct) { gameState.score++; updateScore(); }

            document.querySelectorAll('.option-btn').forEach(b => {
                b.disabled = true;
                if (b.textContent === q.correct_answer) b.classList.add('correct');
                else if (b === btn && !correct) b.classList.add('wrong');
            });

            const fb = document.getElementById('feedback');
            fb.classList.remove('hidden', 'correct', 'wrong');
            fb.classList.add(correct ? 'correct' : 'wrong');
            fb.innerHTML = correct ? '✓ Correct! Well done!' : `✗ Wrong! The answer is ${q.correct_answer}`;

            setTimeout(() => {
                gameState.currentQ++;
                if (gameState.currentQ < 10) loadQuestion();
                else endGame();
            }, 1500);
        }

        function updateScore() { document.getElementById('current-score').textContent = gameState.score; }

        async function endGame() {
            gameState.endTime = new Date();
            const duration = Math.floor((gameState.endTime - gameState.startTime) / 1000);
            showScreen('results');

            document.getElementById('final-score').textContent = gameState.score;
            document.getElementById('result-player').textContent = gameState.playerName;
            document.getElementById('result-correct').textContent = gameState.score + '/10';
            document.getElementById('result-duration').textContent = duration < 60 ? duration + ' seconds' : 
                Math.floor(duration/60) + ' min ' + (duration%60) + ' sec';
            document.getElementById('result-date').textContent = new Date().toLocaleDateString('en-US', {month:'2-digit', day:'2-digit', year:'numeric'});

            let msg = '';
            if (gameState.score === 10) msg = '🏆 Perfect Score! Amazing!';
            else if (gameState.score >= 8) msg = '🌟 Great job! Excellent!';
            else if (gameState.score >= 5) msg = '👍 Good effort! Keep learning!';
            else msg = '📚 Keep practicing!';
            document.getElementById('score-message').textContent = msg;

            // Save score
            const status = document.getElementById('save-status');
            status.className = 'save-status';
            status.textContent = 'Saving your score...';
            try {
                const res = await fetch('index.php?action=save_score', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        username: gameState.playerName, score: gameState.score, total_questions: 10,
                        date_started: gameState.startTime.toISOString().slice(0,19).replace('T',' '),
                        date_ended: gameState.endTime.toISOString().slice(0,19).replace('T',' '),
                        duration_seconds: duration
                    })
                });
                const data = await res.json();
                status.classList.add(data.success ? 'success' : 'error');
                status.textContent = data.success ? '✓ Score saved!' : '✗ Failed to save';
            } catch(e) {
                status.classList.add('error');
                status.textContent = '✗ Could not save';
            }
        }

        async function showHighScores() {
            showScreen('highscores');
            const tbody = document.getElementById('highscores-body');
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:20px;">Loading...</td></tr>';
            try {
                const res = await fetch('index.php?action=get_highscores');
                const data = await res.json();
                tbody.innerHTML = '';
                if (data.highscores && data.highscores.length > 0) {
                    data.highscores.forEach((s, i) => {
                        const rank = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i+1);
                        const cls = i < 3 ? 'rank-' + (i+1) : '';
                        tbody.innerHTML += `<tr><td class="${cls}">${rank}</td><td>${s.username}</td><td>${s.score}/10</td><td>${s.date_played}</td><td>${s.time}</td></tr>`;
                    });
                } else {
                    document.getElementById('no-scores').classList.remove('hidden');
                }
            } catch(e) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#ef4444;">Error loading scores</td></tr>';
            }
        }

        function resetGame() {
            document.getElementById('player-name').value = '';
            document.getElementById('name-error').textContent = '';
            gameState = { playerName: '', questions: [], currentQ: 0, score: 0, startTime: null, endTime: null, answered: false };
            showScreen('welcome');
        }
    </script>
</body>
</html>
