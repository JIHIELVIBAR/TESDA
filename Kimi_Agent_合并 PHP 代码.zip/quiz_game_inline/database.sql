-- TESDA Quiz Game - Database Setup
-- Run this in phpMyAdmin to create the database

CREATE DATABASE IF NOT EXISTS quiz_game CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE quiz_game;

-- Scores table
CREATE TABLE IF NOT EXISTS scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    score INT NOT NULL DEFAULT 0,
    total_questions INT NOT NULL DEFAULT 10,
    date_started DATETIME NOT NULL,
    date_ended DATETIME NOT NULL,
    duration_seconds INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Questions table
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_url VARCHAR(255) NOT NULL,
    correct_answer VARCHAR(100) NOT NULL,
    option_a VARCHAR(100) NOT NULL,
    option_b VARCHAR(100) NOT NULL,
    option_c VARCHAR(100) NOT NULL,
    option_d VARCHAR(100) NOT NULL,
    category ENUM('fruit', 'vegetable') NOT NULL
);

-- Insert Fruit Questions
INSERT INTO questions VALUES
(NULL, 'https://images.unsplash.com/photo-1619546813926-a78fa6372cd2?w=400', 'Apple', 'Apple', 'Orange', 'Grape', 'Mango', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=400', 'Banana', 'Pineapple', 'Banana', 'Papaya', 'Coconut', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1557800636-894a64c1696f?w=400', 'Orange', 'Lemon', 'Lime', 'Orange', 'Grapefruit', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400', 'Grapes', 'Cherries', 'Grapes', 'Blueberries', 'Raspberries', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1553279768-865429fa0078?w=400', 'Mango', 'Peach', 'Mango', 'Apricot', 'Plum', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400', 'Watermelon', 'Pumpkin', 'Watermelon', 'Cantaloupe', 'Honeydew', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400', 'Strawberry', 'Raspberry', 'Cherry', 'Strawberry', 'Cranberry', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?w=400', 'Pineapple', 'Pineapple', 'Durian', 'Jackfruit', 'Breadfruit', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1590004987778-bece5c9adab6?w=400', 'Papaya', 'Papaya', 'Guava', 'Passion Fruit', 'Dragon Fruit', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1574316071802-0d684efa7bf5?w=400', 'Peach', 'Nectarine', 'Apricot', 'Peach', 'Plum', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1603052875302-d376b7c0638a?w=400', 'Avocado', 'Avocado', 'Kiwi', 'Pear', 'Guava', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1585059895524-72359e06138a?w=400', 'Kiwi', 'Lime', 'Kiwi', 'Feijoa', 'Gooseberry', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1514756331096-242fdeb70d4a?w=400', 'Cherry', 'Cherry', 'Cranberry', 'Red Currant', 'Goji Berry', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400', 'Pear', 'Apple', 'Quince', 'Pear', 'Loquat', 'fruit'),
(NULL, 'https://images.unsplash.com/photo-1519096845289-95806ee03a1a?w=400', 'Lemon', 'Lemon', 'Lime', 'Yuzu', 'Citron', 'fruit');

-- Insert Vegetable Questions
INSERT INTO questions VALUES
(NULL, 'https://images.unsplash.com/photo-1597362925123-77861d3fbac7?w=400', 'Carrot', 'Carrot', 'Sweet Potato', 'Pumpkin', 'Squash', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400', 'Tomato', 'Tomato', 'Apple', 'Persimmon', 'Cherry', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400', 'Potato', 'Potato', 'Turnip', 'Radish', 'Beet', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400', 'Onion', 'Garlic', 'Onion', 'Shallot', 'Leek', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?w=400', 'Broccoli', 'Cauliflower', 'Broccoli', 'Cabbage', 'Brussels Sprouts', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1566842600175-97dca489844f?w=400', 'Cucumber', 'Cucumber', 'Zucchini', 'Eggplant', 'Green Bean', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=400', 'Corn', 'Corn', 'Wheat', 'Barley', 'Rice', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?w=400', 'Lettuce', 'Lettuce', 'Spinach', 'Kale', 'Cabbage', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1603048588665-791ca8aea617?w=400', 'Eggplant', 'Eggplant', 'Purple Potato', 'Beet', 'Turnip', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1590362891991-f776e747a588?w=400', 'Bell Pepper', 'Bell Pepper', 'Chili Pepper', 'Jalapeno', 'Paprika', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1601039641847-7857b994d704?w=400', 'Garlic', 'Garlic', 'Onion', 'Ginger', 'Turmeric', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400', 'Spinach', 'Spinach', 'Lettuce', 'Arugula', 'Swiss Chard', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400', 'Cauliflower', 'Cauliflower', 'Broccoli', 'Cabbage', 'Kohlrabi', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1570586437263-162f27db78a7?w=400', 'Pumpkin', 'Pumpkin', 'Squash', 'Gourd', 'Melon', 'vegetable'),
(NULL, 'https://images.unsplash.com/photo-1601039641847-7857b994d704?w=400', 'Mushroom', 'Mushroom', 'Truffle', 'Fungus', 'Toadstool', 'vegetable');
