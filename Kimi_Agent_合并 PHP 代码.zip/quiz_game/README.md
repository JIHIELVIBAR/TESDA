# TESDA Quiz Game - Fruits & Vegetables

A Multiple Choice Quiz Game built for TESDA Web Development NC III Competency Assessment.

## Features

- 🎯 10 random questions per game (fruits & vegetables)
- 👤 Player name entry
- 🖼️ Image-based questions
- ✅ Real-time score tracking
- 🏆 High scores leaderboard
- 💾 Database storage (MySQL)
- 📱 Responsive design
- 🎨 Modern, attractive UI

## File Structure

```
quiz_game/
├── index.html          # Main game interface
├── style.css           # Game styling
├── script.js           # Game logic (JavaScript)
├── api.php             # Backend API (PHP)
├── config.php          # Database configuration
├── database.sql        # Database schema & sample data
└── README.md           # This file
```

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)

## Installation

### 1. Setup Database

1. Open phpMyAdmin or MySQL command line
2. Import the `database.sql` file:
   ```bash
   mysql -u root -p < database.sql
   ```
   Or use phpMyAdmin Import feature

### 2. Configure Database Connection

Edit `config.php` with your database credentials:

```php
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');        // Your MySQL password
define('DB_NAME', 'quiz_game');
```

### 3. Upload Files

Upload all files to your web server (e.g., `htdocs/quiz_game/` for XAMPP)

### 4. Access the Game

Open your browser and navigate to:
```
http://localhost/quiz_game/
```

## How to Play

1. **Start Screen**: Enter your name and click "Start Game"
2. **Gameplay**: Look at the image and select the correct answer from 4 options
3. **Feedback**: See if your answer is correct immediately
4. **Results**: View your final score and see how you rank
5. **High Scores**: Check the leaderboard to see top players

## Game Rules

- 10 random questions per game
- 1 point for each correct answer
- No time limit
- Questions are randomly shuffled each game
- Answer options are randomly positioned

## Database Schema

### Tables

**scores** - Stores player results
- `id` - Primary key
- `username` - Player name
- `score` - Points earned
- `total_questions` - Total questions (10)
- `date_started` - Game start time
- `date_ended` - Game end time
- `duration_seconds` - Time taken to complete

**questions** - Stores quiz questions
- `id` - Primary key
- `image_url` - Image URL
- `correct_answer` - Correct answer
- `option_a/b/c/d` - Multiple choice options
- `category` - fruit or vegetable

## API Endpoints

| Action | Description |
|--------|-------------|
| `get_questions` | Fetch 10 random questions |
| `save_score` | Save player score |
| `get_highscores` | Get top 10 scores |

## Customization

### Add More Questions

Insert new rows into the `questions` table:

```sql
INSERT INTO questions (image_url, correct_answer, option_a, option_b, option_c, option_d, category) 
VALUES ('image_url', 'Correct', 'Opt1', 'Opt2', 'Opt3', 'Opt4', 'fruit');
```

### Change Number of Questions

Edit `api.php` line 24:
```php
LIMIT 10  // Change to desired number
```

And update `script.js` line 10:
```javascript
total_questions: 10  // Match the value
```

## Troubleshooting

### Database Connection Error
- Check `config.php` credentials
- Ensure MySQL is running
- Verify database exists

### Images Not Loading
- Check internet connection (images use Unsplash URLs)
- Or replace with local image paths

### CORS Errors
- Ensure PHP headers are set in `config.php`
- Check that files are on same domain

## Credits

- Built for TESDA Web Development NC III
- Images from Unsplash
- Icons and UI inspired by modern web design

## License

Free for educational use.
