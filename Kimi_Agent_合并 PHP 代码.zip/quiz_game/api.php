<?php
// TESDA Web Development NC III - Quiz Game API
// Backend API for saving scores and retrieving high scores

require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_questions':
        getRandomQuestions();
        break;
    
    case 'save_score':
        saveScore();
        break;
    
    case 'get_highscores':
        getHighScores();
        break;
    
    default:
        sendResponse(['error' => 'Invalid action'], 400);
}

// Get 10 random questions for the game
function getRandomQuestions() {
    $conn = getDBConnection();
    
    $sql = "SELECT id, image_url, correct_answer, option_a, option_b, option_c, option_d, category 
            FROM questions 
            ORDER BY RAND() 
            LIMIT 10";
    
    $result = $conn->query($sql);
    $questions = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Shuffle options for random positioning
            $options = [
                $row['option_a'],
                $row['option_b'],
                $row['option_c'],
                $row['option_d']
            ];
            shuffle($options);
            
            $questions[] = [
                'id' => $row['id'],
                'image_url' => $row['image_url'],
                'correct_answer' => $row['correct_answer'],
                'options' => $options,
                'category' => $row['category']
            ];
        }
    }
    
    $conn->close();
    sendResponse(['questions' => $questions]);
}

// Save player score to database
function saveScore() {
    $data = getJSONInput();
    
    // Validate required fields
    if (!isset($data['username']) || !isset($data['score']) || 
        !isset($data['date_started']) || !isset($data['date_ended']) || 
        !isset($data['duration_seconds'])) {
        sendResponse(['error' => 'Missing required fields'], 400);
    }
    
    $conn = getDBConnection();
    
    $username = $conn->real_escape_string($data['username']);
    $score = intval($data['score']);
    $total_questions = intval($data['total_questions'] ?? 10);
    $date_started = $conn->real_escape_string($data['date_started']);
    $date_ended = $conn->real_escape_string($data['date_ended']);
    $duration_seconds = intval($data['duration_seconds']);
    
    $sql = "INSERT INTO scores (username, score, total_questions, date_started, date_ended, duration_seconds) 
            VALUES ('$username', $score, $total_questions, '$date_started', '$date_ended', $duration_seconds)";
    
    if ($conn->query($sql) === TRUE) {
        $insertId = $conn->insert_id;
        $conn->close();
        sendResponse([
            'success' => true,
            'message' => 'Score saved successfully',
            'id' => $insertId
        ]);
    } else {
        $conn->close();
        sendResponse(['error' => 'Failed to save score: ' . $conn->error], 500);
    }
}

// Get high scores sorted by score (desc) then by duration (asc)
function getHighScores() {
    $conn = getDBConnection();
    
    $sql = "SELECT username, score, total_questions, date_started, date_ended, duration_seconds 
            FROM scores 
            ORDER BY score DESC, duration_seconds ASC 
            LIMIT 10";
    
    $result = $conn->query($sql);
    $highScores = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $highScores[] = [
                'username' => $row['username'],
                'score' => $row['score'],
                'total_questions' => $row['total_questions'],
                'date_played' => date('m/d/Y', strtotime($row['date_started'])),
                'time' => formatDuration($row['duration_seconds'])
            ];
        }
    }
    
    $conn->close();
    sendResponse(['highscores' => $highScores]);
}

// Format duration in seconds to readable format
function formatDuration($seconds) {
    if ($seconds < 60) {
        return $seconds . ' seconds';
    } else {
        $minutes = floor($seconds / 60);
        $remainingSeconds = $seconds % 60;
        return $minutes . ' min ' . $remainingSeconds . ' sec';
    }
}
?>
