// TESDA Web Development NC III - Quiz Game JavaScript
// Fruits & Vegetables Multiple Choice Quiz Game

// Game State
let gameState = {
    playerName: '',
    questions: [],
    currentQuestionIndex: 0,
    score: 0,
    startTime: null,
    endTime: null,
    isAnswered: false
};

// DOM Elements
const screens = {
    welcome: document.getElementById('welcome-screen'),
    game: document.getElementById('game-screen'),
    results: document.getElementById('results-screen'),
    highscores: document.getElementById('highscores-screen')
};

// API Base URL (change this to your server URL)
const API_URL = 'api.php';

// Initialize the game
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});

// Setup all event listeners
function setupEventListeners() {
    // Welcome Screen
    document.getElementById('start-btn').addEventListener('click', startGame);
    document.getElementById('player-name').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') startGame();
    });
    document.getElementById('view-highscores-btn').addEventListener('click', showHighScores);
    
    // Results Screen
    document.getElementById('play-again-btn').addEventListener('click', resetGame);
    document.getElementById('view-scores-btn').addEventListener('click', showHighScores);
    
    // High Scores Screen
    document.getElementById('back-btn').addEventListener('click', () => showScreen('welcome'));
}

// Show specific screen
function showScreen(screenName) {
    Object.values(screens).forEach(screen => screen.classList.remove('active'));
    screens[screenName].classList.add('active');
}

// Start the game
async function startGame() {
    const playerNameInput = document.getElementById('player-name');
    const nameError = document.getElementById('name-error');
    
    const playerName = playerNameInput.value.trim();
    
    // Validate player name
    if (!playerName) {
        nameError.textContent = 'Please enter your name to start the game.';
        playerNameInput.focus();
        return;
    }
    
    if (playerName.length < 2) {
        nameError.textContent = 'Name must be at least 2 characters long.';
        playerNameInput.focus();
        return;
    }
    
    nameError.textContent = '';
    gameState.playerName = playerName;
    
    // Show loading state
    document.getElementById('start-btn').textContent = 'Loading...';
    document.getElementById('start-btn').disabled = true;
    
    try {
        // Fetch questions from API
        const response = await fetch(`${API_URL}?action=get_questions`);
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        gameState.questions = data.questions;
        
        if (gameState.questions.length === 0) {
            throw new Error('No questions available. Please check the database.');
        }
        
        // Initialize game
        gameState.currentQuestionIndex = 0;
        gameState.score = 0;
        gameState.startTime = new Date();
        gameState.isAnswered = false;
        
        // Update UI
        document.getElementById('current-player').textContent = gameState.playerName;
        updateScoreDisplay();
        
        // Show game screen
        showScreen('game');
        
        // Load first question
        loadQuestion();
        
    } catch (error) {
        alert('Error starting game: ' + error.message);
        console.error('Error:', error);
    } finally {
        document.getElementById('start-btn').textContent = 'Start Game';
        document.getElementById('start-btn').disabled = false;
    }
}

// Load current question
function loadQuestion() {
    const question = gameState.questions[gameState.currentQuestionIndex];
    
    // Update progress
    const progress = ((gameState.currentQuestionIndex + 1) / gameState.questions.length) * 100;
    document.getElementById('progress-fill').style.width = `${progress}%`;
    document.getElementById('question-number').textContent = gameState.currentQuestionIndex + 1;
    
    // Show loading
    document.getElementById('loading').classList.remove('hidden');
    
    // Load image
    const img = document.getElementById('question-image');
    img.onload = () => {
        document.getElementById('loading').classList.add('hidden');
    };
    img.onerror = () => {
        document.getElementById('loading').textContent = 'Image failed to load';
    };
    img.src = question.image_url;
    
    // Generate options
    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.className = 'option-btn';
        button.textContent = option;
        button.addEventListener('click', () => handleAnswer(option, button));
        optionsContainer.appendChild(button);
    });
    
    // Hide feedback
    document.getElementById('feedback').classList.add('hidden');
    
    gameState.isAnswered = false;
}

// Handle answer selection
function handleAnswer(selectedAnswer, buttonElement) {
    if (gameState.isAnswered) return;
    
    gameState.isAnswered = true;
    
    const question = gameState.questions[gameState.currentQuestionIndex];
    const isCorrect = selectedAnswer === question.correct_answer;
    
    // Update score
    if (isCorrect) {
        gameState.score++;
        updateScoreDisplay();
    }
    
    // Show visual feedback
    const allButtons = document.querySelectorAll('.option-btn');
    allButtons.forEach(btn => {
        btn.disabled = true;
        if (btn.textContent === question.correct_answer) {
            btn.classList.add('correct');
        } else if (btn === buttonElement && !isCorrect) {
            btn.classList.add('wrong');
        }
    });
    
    // Show feedback message
    const feedback = document.getElementById('feedback');
    const feedbackIcon = document.getElementById('feedback-icon');
    const feedbackText = document.getElementById('feedback-text');
    
    feedback.classList.remove('hidden', 'correct', 'wrong');
    
    if (isCorrect) {
        feedback.classList.add('correct');
        feedbackIcon.textContent = '✓';
        feedbackText.textContent = 'Correct! Well done!';
    } else {
        feedback.classList.add('wrong');
        feedbackIcon.textContent = '✗';
        feedbackText.textContent = `Wrong! The correct answer is ${question.correct_answer}`;
    }
    
    // Move to next question after delay
    setTimeout(() => {
        gameState.currentQuestionIndex++;
        
        if (gameState.currentQuestionIndex < gameState.questions.length) {
            loadQuestion();
        } else {
            endGame();
        }
    }, 1500);
}

// Update score display
function updateScoreDisplay() {
    document.getElementById('current-score').textContent = gameState.score;
}

// End the game
async function endGame() {
    gameState.endTime = new Date();
    
    const durationSeconds = Math.floor((gameState.endTime - gameState.startTime) / 1000);
    
    // Show results screen
    showScreen('results');
    
    // Display results
    document.getElementById('final-score').textContent = gameState.score;
    document.getElementById('result-player').textContent = gameState.playerName;
    document.getElementById('result-correct').textContent = `${gameState.score}/10`;
    document.getElementById('result-duration').textContent = formatDuration(durationSeconds);
    document.getElementById('result-date').textContent = formatDate(gameState.endTime);
    
    // Score message
    const scoreMessage = document.getElementById('score-message');
    if (gameState.score === 10) {
        scoreMessage.textContent = '🏆 Perfect Score! Amazing!';
    } else if (gameState.score >= 8) {
        scoreMessage.textContent = '🌟 Great job! Excellent knowledge!';
    } else if (gameState.score >= 5) {
        scoreMessage.textContent = '👍 Good effort! Keep learning!';
    } else {
        scoreMessage.textContent = '📚 Keep practicing! You\'ll do better next time!';
    }
    
    // Save score to database
    await saveScore(durationSeconds);
}

// Save score to database
async function saveScore(durationSeconds) {
    const saveStatus = document.getElementById('save-status');
    saveStatus.className = 'save-status';
    saveStatus.textContent = 'Saving your score...';
    
    try {
        const response = await fetch(`${API_URL}?action=save_score`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: gameState.playerName,
                score: gameState.score,
                total_questions: gameState.questions.length,
                date_started: gameState.startTime.toISOString().slice(0, 19).replace('T', ' '),
                date_ended: gameState.endTime.toISOString().slice(0, 19).replace('T', ' '),
                duration_seconds: durationSeconds
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            saveStatus.classList.add('success');
            saveStatus.textContent = '✓ Score saved successfully!';
        } else {
            throw new Error(data.error || 'Failed to save score');
        }
    } catch (error) {
        saveStatus.classList.add('error');
        saveStatus.textContent = '✗ Could not save score: ' + error.message;
        console.error('Error saving score:', error);
    }
}

// Show high scores
async function showHighScores() {
    showScreen('highscores');
    
    const tbody = document.getElementById('highscores-body');
    const noScores = document.getElementById('no-scores');
    
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:20px;">Loading...</td></tr>';
    noScores.classList.add('hidden');
    
    try {
        const response = await fetch(`${API_URL}?action=get_highscores`);
        const data = await response.json();
        
        tbody.innerHTML = '';
        
        if (data.highscores && data.highscores.length > 0) {
            data.highscores.forEach((score, index) => {
                const row = document.createElement('tr');
                
                const rankClass = index === 0 ? 'rank-1' : index === 1 ? 'rank-2' : index === 2 ? 'rank-3' : '';
                const rankIcon = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : (index + 1);
                
                row.innerHTML = `
                    <td class="${rankClass}">${rankIcon}</td>
                    <td>${escapeHtml(score.username)}</td>
                    <td>${score.score}/${score.total_questions}</td>
                    <td>${score.date_played}</td>
                    <td>${score.time}</td>
                `;
                
                tbody.appendChild(row);
            });
        } else {
            noScores.classList.remove('hidden');
        }
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:20px;color:#ef4444;">Error loading scores: ${error.message}</td></tr>`;
        console.error('Error fetching high scores:', error);
    }
}

// Reset game
function resetGame() {
    // Clear input
    document.getElementById('player-name').value = '';
    document.getElementById('name-error').textContent = '';
    
    // Reset game state
    gameState = {
        playerName: '',
        questions: [],
        currentQuestionIndex: 0,
        score: 0,
        startTime: null,
        endTime: null,
        isAnswered: false
    };
    
    // Show welcome screen
    showScreen('welcome');
}

// Format duration
function formatDuration(seconds) {
    if (seconds < 60) {
        return seconds + ' seconds';
    } else {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return minutes + ' min ' + remainingSeconds + ' sec';
    }
}

// Format date
function formatDate(date) {
    return date.toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric'
    });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
