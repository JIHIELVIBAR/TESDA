-- TESDA Web Development NC III - Multiple Choice Quiz Game Database
-- Fruits and Vegetables Quiz

CREATE DATABASE IF NOT EXISTS quiz_game CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE quiz_game;

-- Table for storing player scores
CREATE TABLE IF NOT EXISTS scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    score INT NOT NULL DEFAULT 0,
    total_questions INT NOT NULL DEFAULT 10,
    date_started DATETIME NOT NULL,
    date_ended DATETIME NOT NULL,
    duration_seconds INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for quiz questions (fruits and vegetables)
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_url VARCHAR(255) NOT NULL,
    correct_answer VARCHAR(100) NOT NULL,
    option_a VARCHAR(100) NOT NULL,
    option_b VARCHAR(100) NOT NULL,
    option_c VARCHAR(100) NOT NULL,
    option_d VARCHAR(100) NOT NULL,
    category ENUM('fruit', 'vegetable') NOT NULL
);

-- Insert sample fruit questions
INSERT INTO questions (image_url, correct_answer, option_a, option_b, option_c, option_d, category) VALUES
('https://images.unsplash.com/photo-1619546813926-a78fa6372cd2?w=300', 'Apple', 'Apple', 'Orange', 'Grape', 'Mango', 'fruit'),
('https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=300', 'Banana', 'Pineapple', 'Banana', 'Papaya', 'Coconut', 'fruit'),
('https://images.unsplash.com/photo-1557800636-894a64c1696f?w=300', 'Orange', 'Lemon', 'Lime', 'Orange', 'Grapefruit', 'fruit'),
('https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=300', 'Grapes', 'Cherries', 'Grapes', 'Blueberries', 'Raspberries', 'fruit'),
('https://images.unsplash.com/photo-1553279768-865429fa0078?w=300', 'Mango', 'Peach', 'Mango', 'Apricot', 'Plum', 'fruit'),
('https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=300', 'Watermelon', 'Pumpkin', 'Watermelon', 'Cantaloupe', 'Honeydew', 'fruit'),
('https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=300', 'Strawberry', 'Raspberry', 'Cherry', 'Strawberry', 'Cranberry', 'fruit'),
('https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?w=300', 'Pineapple', 'Pineapple', 'Durian', 'Jackfruit', 'Breadfruit', 'fruit'),
('https://images.unsplash.com/photo-1590004987778-bece5c9adab6?w=300', 'Papaya', 'Papaya', 'Guava', 'Passion Fruit', 'Dragon Fruit', 'fruit'),
('https://images.unsplash.com/photo-1574316071802-0d684efa7bf5?w=300', 'Peach', 'Nectarine', 'Apricot', 'Peach', 'Plum', 'fruit'),
('https://images.unsplash.com/photo-1603052875302-d376b7c0638a?w=300', 'Avocado', 'Avocado', 'Kiwi', 'Pear', 'Guava', 'fruit'),
('https://images.unsplash.com/photo-1585059895524-72359e06138a?w=300', 'Kiwi', 'Lime', 'Kiwi', 'Feijoa', 'Gooseberry', 'fruit'),
('https://images.unsplash.com/photo-1514756331096-242fdeb70d4a?w=300', 'Cherry', 'Cherry', 'Cranberry', 'Red Currant', 'Goji Berry', 'fruit'),
('https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=300', 'Pear', 'Apple', 'Quince', 'Pear', 'Loquat', 'fruit'),
('https://images.unsplash.com/photo-1519096845289-95806ee03a1a?w=300', 'Lemon', 'Lemon', 'Lime', 'Yuzu', 'Citron', 'fruit');

-- Insert sample vegetable questions
INSERT INTO questions (image_url, correct_answer, option_a, option_b, option_c, option_d, category) VALUES
('https://images.unsplash.com/photo-1597362925123-77861d3fbac7?w=300', 'Carrot', 'Carrot', 'Sweet Potato', 'Pumpkin', 'Squash', 'vegetable'),
('https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=300', 'Tomato', 'Tomato', 'Apple', 'Persimmon', 'Cherry', 'vegetable'),
('https://images.unsplash.com/photo-1586201375761-83865001e31c?w=300', 'Potato', 'Potato', 'Turnip', 'Radish', 'Beet', 'vegetable'),
('https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=300', 'Onion', 'Garlic', 'Onion', 'Shallot', 'Leek', 'vegetable'),
('https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?w=300', 'Broccoli', 'Cauliflower', 'Broccoli', 'Cabbage', 'Brussels Sprouts', 'vegetable'),
('https://images.unsplash.com/photo-1566842600175-97dca489844f?w=300', 'Cucumber', 'Cucumber', 'Zucchini', 'Eggplant', 'Green Bean', 'vegetable'),
('https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?w=300', 'Corn', 'Corn', 'Wheat', 'Barley', 'Rice', 'vegetable'),
('https://images.unsplash.com/photo-1592417817098-8fd3d9eb14a5?w=300', 'Lettuce', 'Lettuce', 'Spinach', 'Kale', 'Cabbage', 'vegetable'),
('https://images.unsplash.com/photo-1603048588665-791ca8aea617?w=300', 'Eggplant', 'Eggplant', 'Purple Potato', 'Beet', 'Turnip', 'vegetable'),
('https://images.unsplash.com/photo-1590362891991-f776e747a588?w=300', 'Bell Pepper', 'Bell Pepper', 'Chili Pepper', 'Jalapeno', 'Paprika', 'vegetable'),
('https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=300', 'Garlic', 'Garlic', 'Onion', 'Ginger', 'Turmeric', 'vegetable'),
('https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=300', 'Spinach', 'Spinach', 'Lettuce', 'Arugula', 'Swiss Chard', 'vegetable'),
('https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=300', 'Cauliflower', 'Cauliflower', 'Broccoli', 'Cabbage', 'Kohlrabi', 'vegetable'),
('https://images.unsplash.com/photo-1603048588665-791ca8aea617?w=300', 'Pumpkin', 'Pumpkin', 'Squash', 'Gourd', 'Melon', 'vegetable'),
('https://images.unsplash.com/photo-1601039641847-7857b994d704?w=300', 'Mushroom', 'Mushroom', 'Truffle', 'Fungus', 'Toadstool', 'vegetable');
